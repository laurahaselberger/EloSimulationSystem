using Model.Entities.Projects;

namespace Domain.Repositories.Interfaces;

public interface IProjectRepository : IRepository<AProject> {
    
}