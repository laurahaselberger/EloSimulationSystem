namespace Shared.Entities.Facilities;

public class CreateFacilityDto {
    public string Name { get; set; } = null!;
}