namespace Shared.Entities.Facilities;

public class DefaultFacilityDto {
    public int Id { get; set; }
    public string Name { get; set; } = null!;

}