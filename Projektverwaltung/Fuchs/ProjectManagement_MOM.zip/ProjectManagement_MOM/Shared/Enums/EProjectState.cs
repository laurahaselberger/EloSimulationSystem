namespace Shared.Enums;

public enum EProjectState {
    Created,
    Cancelled,
    Approved
}