namespace Shared.Enums;

public enum ELawType {
    P27,
    P28,
    P29
}