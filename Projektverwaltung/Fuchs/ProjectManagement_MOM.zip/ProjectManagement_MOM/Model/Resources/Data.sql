use projectsdb;

INSERT INTO facilities(FACILITY_ID, FACILITY_NAME) 
VALUES (1, 'Architecture'),
       (2, 'Electrical Engineering'),
       (3, 'Chemistry');