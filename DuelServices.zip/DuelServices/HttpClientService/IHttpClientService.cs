﻿namespace HttpClientService; 

public interface IHttpClientService
{
    HttpClient Client { get; }
}