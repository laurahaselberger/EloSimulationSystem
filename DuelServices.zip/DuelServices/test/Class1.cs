﻿namespace test;

public class Class1 {
}