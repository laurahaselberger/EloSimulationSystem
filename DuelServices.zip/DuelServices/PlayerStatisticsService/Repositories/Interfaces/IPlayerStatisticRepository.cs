﻿
using PlayerStatisticsService.Entities;

namespace PlayerStatisticsService.Repositories.Interfaces; 

public interface IPlayerStatisticRepository : IRepository<PlayerStatistic>
{
}