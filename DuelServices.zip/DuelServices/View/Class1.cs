﻿namespace View;

public class Class1
{
}