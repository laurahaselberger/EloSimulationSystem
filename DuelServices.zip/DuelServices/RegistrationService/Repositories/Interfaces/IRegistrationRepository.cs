﻿using System.Linq.Expressions;
using RegistrationService.Entities;

namespace RegistrationService.Repositories.Interfaces;

public interface IRegistrationRepository : IRepository<Player>
{
    
}