﻿namespace Model.Entities;

public class Player
{
    
}