﻿using Model.Entities;

namespace Domain.Repository.Implementations;


public class PlayerRepository : ARepository<Player>
{
    
}